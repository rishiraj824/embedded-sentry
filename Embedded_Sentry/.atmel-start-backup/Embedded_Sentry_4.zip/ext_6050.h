/*
 * ext_6050.h
 *
 * Created: 4/25/2020 9:30:43 AM
 *  Author: rishi
 */ 


#ifndef EXT_6050_H_
#define EXT_6050_H_


#include "driver_init.h"

struct io_descriptor *ext_6050_io;

// Reset command
#define MPU6050_ADDRESS_AD0_LOW     0x68 // address pin low (GND), default for InvenSense evaluation board
#define MPU6050_ADDRESS_AD0_HIGH    0x69 // address pin high (VCC)
#define MPU6050_DEFAULT_ADDRESS     MPU6050_ADDRESS_AD0_LOW

#define MPU6050_RA_XG_OFFS_TC       0x00 //[7] PWR_MODE, [6:1] XG_OFFS_TC, [0] OTP_BNK_VLD
#define MPU6050_RA_YG_OFFS_TC       0x01 //[7] PWR_MODE, [6:1] YG_OFFS_TC, [0] OTP_BNK_VLD
#define MPU6050_RA_ZG_OFFS_TC       0x02 //[7] PWR_MODE, [6:1] ZG_OFFS_TC, [0] OTP_BNK_VLD


#define MPU6050_RA_I2C_MST_CTRL     0x24
#define MPU6050_RA_I2C_SLV0_ADDR    0x25
#define MPU6050_RA_I2C_SLV0_REG     0x26
#define MPU6050_RA_I2C_SLV0_CTRL    0x27
#define MPU6050_RA_I2C_SLV1_ADDR    0x28
#define MPU6050_RA_I2C_SLV1_REG     0x29
#define MPU6050_RA_I2C_SLV1_CTRL    0x2A
#define MPU6050_RA_I2C_SLV2_ADDR    0x2B
#define MPU6050_RA_I2C_SLV2_REG     0x2C
#define MPU6050_RA_I2C_SLV2_CTRL    0x2D
#define MPU6050_RA_I2C_SLV3_ADDR    0x2E
#define MPU6050_RA_I2C_SLV3_REG     0x2F
#define MPU6050_RA_I2C_SLV3_CTRL    0x30
#define MPU6050_RA_I2C_SLV4_ADDR    0x31
#define MPU6050_RA_I2C_SLV4_REG     0x32
#define MPU6050_RA_I2C_SLV4_DO      0x33
#define MPU6050_RA_I2C_SLV4_CTRL    0x34
#define MPU6050_RA_I2C_SLV4_DI      0x35
#define MPU6050_RA_I2C_SLV0_DO      0x63
#define MPU6050_RA_I2C_SLV1_DO      0x64
#define MPU6050_RA_I2C_SLV2_DO      0x65
#define MPU6050_RA_I2C_SLV3_DO      0x66

#define MPU6050_VDDIO_LEVEL_VLOGIC  0
#define MPU6050_VDDIO_LEVEL_VDD     1



#define MPU6050_I2C_SLV_RW_BIT      7
#define MPU6050_I2C_SLV_ADDR_BIT    6
#define MPU6050_I2C_SLV_ADDR_LENGTH 7
#define MPU6050_I2C_SLV_EN_BIT      7
#define MPU6050_I2C_SLV_BYTE_SW_BIT 6
#define MPU6050_I2C_SLV_REG_DIS_BIT 5
#define MPU6050_I2C_SLV_GRP_BIT     4
#define MPU6050_I2C_SLV_LEN_BIT     3
#define MPU6050_I2C_SLV_LEN_LENGTH  4

#define MPU6050_I2C_SLV4_RW_BIT         7
#define MPU6050_I2C_SLV4_ADDR_BIT       6
#define MPU6050_I2C_SLV4_ADDR_LENGTH    7
#define MPU6050_I2C_SLV4_EN_BIT         7
#define MPU6050_I2C_SLV4_INT_EN_BIT     6
#define MPU6050_I2C_SLV4_REG_DIS_BIT    5
#define MPU6050_I2C_SLV4_MST_DLY_BIT    4
#define MPU6050_I2C_SLV4_MST_DLY_LENGTH 5

#define MPU6050_WHO_AM_I_BIT        6
#define MPU6050_WHO_AM_I_LENGTH     6

#define MPU6050_CLOCK_INTERNAL          0x00

class MPU6050 {
	public:
	MPU6050(uint8_t address=MPU6050_DEFAULT_ADDRESS);

	void initialize();
	bool testConnection();

	// AUX_VDDIO register
	uint8_t getAuxVDDIOLevel();
	void setAuxVDDIOLevel(uint8_t level);
	
    // SMPLRT_DIV register
    uint8_t getRate();
    void setRate(uint8_t rate);

    // CONFIG register
    uint8_t getExternalFrameSync();
    void setExternalFrameSync(uint8_t sync);
    uint8_t getDLPFMode();
    void setDLPFMode(uint8_t bandwidth);

    // GYRO_CONFIG register
    uint8_t getFullScaleGyroRange();
    void setFullScaleGyroRange(uint8_t range);
	
	// I2C_SLV* registers (Slave 0-3)
    uint8_t getSlaveAddress(uint8_t num);
    void setSlaveAddress(uint8_t num, uint8_t address);
    uint8_t getSlaveRegister(uint8_t num);
    void setSlaveRegister(uint8_t num, uint8_t reg);
    bool getSlaveEnabled(uint8_t num);
    void setSlaveEnabled(uint8_t num, bool enabled);
    bool getSlaveWordByteSwap(uint8_t num);
    void setSlaveWordByteSwap(uint8_t num, bool enabled);
    bool getSlaveWriteMode(uint8_t num);
    void setSlaveWriteMode(uint8_t num, bool mode);
    bool getSlaveWordGroupOffset(uint8_t num);
    void setSlaveWordGroupOffset(uint8_t num, bool enabled);
    uint8_t getSlaveDataLength(uint8_t num);
    void setSlaveDataLength(uint8_t num, uint8_t length);

    // I2C_SLV* registers (Slave 4)
    uint8_t getSlave4Address();
    void setSlave4Address(uint8_t address);
    uint8_t getSlave4Register();
    void setSlave4Register(uint8_t reg);
    void setSlave4OutputByte(uint8_t data);
    bool getSlave4Enabled();
    void setSlave4Enabled(bool enabled);
    bool getSlave4InterruptEnabled();
    void setSlave4InterruptEnabled(bool enabled);
    bool getSlave4WriteMode();
    void setSlave4WriteMode(bool mode);
    uint8_t getSlave4MasterDelay();
    void setSlave4MasterDelay(uint8_t delay);
    uint8_t getSlate4InputByte();

    // I2C_MST_STATUS register
    bool getPassthroughStatus();
    bool getSlave4IsDone();
    bool getLostArbitration();
    bool getSlave4Nack();
    bool getSlave3Nack();
    bool getSlave2Nack();
    bool getSlave1Nack();
    bool getSlave0Nack();

    // INT_PIN_CFG register
    bool getInterruptMode();
    void setInterruptMode(bool mode);
    bool getInterruptDrive();
    void setInterruptDrive(bool drive);
    bool getInterruptLatch();
    void setInterruptLatch(bool latch);
    bool getInterruptLatchClear();
    void setInterruptLatchClear(bool clear);
    bool getFSyncInterruptLevel();
    void setFSyncInterruptLevel(bool level);
    bool getFSyncInterruptEnabled();
    void setFSyncInterruptEnabled(bool enabled);
    bool getI2CBypassEnabled();
    void setI2CBypassEnabled(bool enabled);
    bool getClockOutputEnabled();
    void setClockOutputEnabled(bool enabled);

    // INT_ENABLE register
    uint8_t getIntEnabled();
    void setIntEnabled(uint8_t enabled);
    bool getIntFreefallEnabled();
    void setIntFreefallEnabled(bool enabled);
    bool getIntMotionEnabled();
    void setIntMotionEnabled(bool enabled);
    bool getIntZeroMotionEnabled();
    void setIntZeroMotionEnabled(bool enabled);
    bool getIntFIFOBufferOverflowEnabled();
    void setIntFIFOBufferOverflowEnabled(bool enabled);
    bool getIntI2CMasterEnabled();
    void setIntI2CMasterEnabled(bool enabled);
    bool getIntDataReadyEnabled();
    void setIntDataReadyEnabled(bool enabled);

    // INT_STATUS register
    uint8_t getIntStatus();
    bool getIntFreefallStatus();
    bool getIntMotionStatus();
    bool getIntZeroMotionStatus();
    bool getIntFIFOBufferOverflowStatus();
    bool getIntI2CMasterStatus();
    bool getIntDataReadyStatus();

    // ACCEL_*OUT_* registers
    void getMotion9(int16_t* ax, int16_t* ay, int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz, int16_t* mx, int16_t* my, int16_t* mz);
    void getMotion6(int16_t* ax, int16_t* ay, int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz);
    void getAcceleration(int16_t* x, int16_t* y, int16_t* z);
    int16_t getAccelerationX();
    int16_t getAccelerationY();
    int16_t getAccelerationZ();

	
	// GYRO_*OUT_* registers
	void getRotation(int16_t* x, int16_t* y, int16_t* z);
	int16_t getRotationX();
	int16_t getRotationY();
	int16_t getRotationZ();
	private:
		uint8_t devAddr;
		uint8_t buffer[14];
}




#endif /* EXT_6050_H_ */