/*
#include "atmel_start.h"
#include "driver_init.h"
#include "utils.h"
//#include <inttypes.h>
#include <stdio.h>

//#define WHO_AM_I   0x75
//#define I2C_SLV0_ADDR 0x25
#define ADDRESS    0x68


//struct io_descriptor *I2C_0_io;
//struct io_descriptor *I2C_0_io_uart;
//struct i2c_m_sync_desc I2C_0_io;
static uint8_t buffer[14];

void UART_EDBG_init(){
	usart_sync_get_io_descriptor(&USART_0, &I2C_0_io_uart);
	usart_sync_enable(&USART_0);
}
*/
/*
void linear_reg(int dataset[]){
	// find W such that W = X^-1 y is (1x1) and X is 
}

void average_wegihts(int w){
	w = (w1 + w2 )/2	
}

void isGesture() {
	y = W*X
	if (y>0.9) {
		blink led twice
	}
	else {
	    blink led once	
	}
}

int logInputs(int16_t acX, int16_t acY, int16_t acZ){
  // create a matrix X_n of dimension (nx3)) for n such calls of logInputs
  // format => [[acX1, acY1, acZ1], [acX2, acY2, acZ2],......[acXN, acYN, acZYN]]
  
  return X_n
}

void recordGesture(){
	int counter = 10;
	// blink LED
	gpio_toggle_pin_level(BLINK_LED);
	
	while (counter)
	{
		counter--;
		
	}
}

*/
/*
int main(void)
{
	/* Initializes MCU, drivers and middleware 
	atmel_start_init();
	// page 264, asf guide
	//int32_t ack = i2c_m_sync_init(&I2C_0, SERCOM0);
	
	//printf("I2C init - %d\n",ack);
	//int32_t ack2 = i2c_m_sync_get_io_descriptor(&I2C_0, &I2C_0_io);
	
	//printf("IO Descriptor ran successfully - %d\n", ack2);
	
	
	//int32_t ack_baud = i2c_m_sync_set_baudrate(&I2C_0, 0, 400000);
	
	//printf("Baud rate set successfully: %d\n",ack_baud);
	
	int32_t ack3 = i2c_m_sync_enable(&I2C_0);
	printf("I2C Enabled - %d\n",ack3);
	
	

	// initialize the USART for debug
	//UART_EDBG_init();
	
	int32_t slave_addr = i2c_m_sync_set_slaveaddr(&I2C_0, ADDRESS, I2C_M_SEVEN);
	
	printf("Masked Slave Address - %d\n", slave_addr);
	//static struct io_descriptor *io;
	int counter = 0;
	// on button press
	// recordGesture();
	
	uint8_t pwr_mgmt =  0;

	//static uint8_t wake_up_mgmt[1] =   {0x0};
 	int32_t power_up = i2c_m_sync_cmd_write(&I2C_0, 0x6b, &pwr_mgmt, 1);

	printf("Power up ack : %d\n", power_up);
	
	//int32_t wake_up = i2c_m_sync_cmd_write(&I2C_0, ADDRESS, wake_up_mgmt, 1);
	
	//printf("Wake up ack : %d\n", wake_up);
	
	/* Replace with your application code */
	/*
	while (true) {
		//gpio_toggle_pin_level(BLINK_LED);
		// delay
		
		//static uint8_t buffer[1] = { 0x3b };
		
		delay_ms(2000);
		
		//unsigned char addr = ADDRESS;
		
		//int32_t write_ack = i2c_m_sync_cmd_write(&I2C_0, ADDRESS, writeBuffer, 1);
		
		//printf("Successfully written the address: %d\n", write_ack);
	
		
		//delay_ms(2000);
		
		int32_t read_ack = i2c_m_sync_cmd_read(&I2C_0, (uint8_t)0x3b, buffer, 14);
		//int32_t read_ack = io_read(io, &buffer, 1);
		
		printf("Successfully read from the device: %d\n", read_ack);

		int16_t acX = buffer[counter++] << 8 | buffer[counter++]; // 0x3B (ACCEL_XOUT_H) & 0x3C (ACCEL_XOUT_L)
		int16_t acY = buffer[counter++] << 8 | buffer[counter++]; // 0x3D (ACCEL_YOUT_H) & 0x3E (ACCEL_YOUT_L)
		int16_t acZ = buffer[counter++] << 8 | buffer[counter++]; // 0x3F (ACCEL_ZOUT_H) & 0x40 (ACCEL_ZOUT_L)
		int16_t tmp = buffer[counter++] << 8 | buffer[counter++]; // 0x41 (TEMP_OUT_H) & 0x42 (TEMP_OUT_L)
		int16_t gyX = buffer[counter++] << 8 | buffer[counter++]; // 0x43 (GYRO_XOUT_H) & 0x44 (GYRO_XOUT_L)
		int16_t gyY = buffer[counter++] << 8 | buffer[counter++]; // 0x45 (GYRO_YOUT_H) & 0x46 (GYRO_YOUT_L)
		int16_t gyZ = buffer[counter++] << 8 | buffer[counter++]; // 0x47 (GYRO_ZOUT_H) & 0x48 (GYRO_ZOUT_L)


		//logInputs(acX, acY, acZ, gyX, gyY, gyZ);
		printf("X: %d, Y: %d, Z: %d, tmp: %d, gyX: %d, gyY: %d, gyZ: %d, Buffer: %d\n", acX, acY, acZ, tmp, gyX, gyY, gyZ, buffer);
		//printf("acX: %d\n", buffer[0]);
		//io_write(I2C_0_io, (uint8_t *)"Hello World!\n", 12);

		counter = 0;
	}
	
}
*/