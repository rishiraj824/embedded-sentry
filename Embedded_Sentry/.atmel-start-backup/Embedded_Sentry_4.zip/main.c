#include "driver_init.h"
#include "utils.h"
#include <hal_gpio.h>
#include <hal_delay.h>
#include <stdio.h>


#define SW0 GPIO(GPIO_PORTA, 15)
#define LED0 GPIO(GPIO_PORTB, 30)

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	struct io_descriptor *I2C_0_io;
	i2c_m_sync_get_io_descriptor(&I2C_0, &I2C_0_io);
	int32_t ack3 = i2c_m_sync_enable(&I2C_0);
	printf("I2C Enabled - %d\n",ack3);
	
	int32_t slave_addr = i2c_m_sync_set_slaveaddr(&I2C_0, 0x68, I2C_M_SEVEN);
	
	printf("Masked Slave Address - %d\n", slave_addr);
	
	
	uint8_t readBuffer;
	int32_t readData = i2c_m_sync_cmd_read(&I2C_0, 0x75, &readBuffer, 1);

	printf("read data : : %x\n", readData);
	printf("Read Buffer : %x\n", readBuffer);
	delay_ms(500);
	uint8_t readbuffer;
	int32_t read_ack = i2c_m_sync_cmd_read(&I2C_0, 0x6b, &readbuffer, 1);
	printf("\nread_ack : %d\n",read_ack);
	printf("readbuffer : %x\n",readbuffer);
	delay_ms(500);
	uint8_t writebuffer = 0x20;
	int32_t write = i2c_m_sync_cmd_write(&I2C_0, 0x6b, &writebuffer, 1);
	// 	uint8_t buf[2]={0x24,0x01};
	// 	i2c_m_sync_enable(&I2C_0);
	// 	i2c_m_sync_set_slaveaddr(&I2C_0, 0x12, I2C_M_SEVEN);
	// 	int32_t write = io_write(I2C_0_io, (uint8_t *)buf, 2
	
	
	printf("write : %d\n", write);
	delay_ms(500);
	uint8_t readbuffer1;
	int32_t read_ack1 = i2c_m_sync_cmd_read(&I2C_0, 0x6b, &readbuffer1, 1);
	printf("\nread_ack1 : %d\n",read_ack1);
	printf("readbuffer1 : %x      ",readbuffer1);
	// 		static uint8_t buffer[6];
	// 		int32_t read_ack = i2c_m_sync_cmd_read(&I2C_0, 0x3b, buffer, 6);
	// 		printf("\nread_ack : %d\n",read_ack);
	// 		for(int j =0;j<=6;j++)
	// 			printf("i : %x    buffer : %x      ",j,buffer[j]);
	//
	int counter = 0;
	int  i = 0;
	
	gpio_set_pin_pull_mode(SW0, GPIO_PULL_UP);
	

	while (true) {
		do {
			delay_ms(100);
		} while (gpio_get_pin_level(SW0));

		gpio_toggle_pin_level(LED0);

		do {
			delay_ms(100);
		} while (!gpio_get_pin_level(SW0));
	}
	/*
	while(true){
		//static uint8_t writebuffer[1] = {0x20};
		//int32_t power_up = i2c_m_sync_cmd_write(&I2C_0, 0x6b, &writebuffer, 1);
		

		//printf("Power up ack : %d\n", power_up);
		//delay_ms(200);
		// 		static uint8_t readbuffer[1];
		// 		int32_t read_ack1 = i2c_m_sync_cmd_read(&I2C_0, 0x6b, readbuffer, 1);
		// 		printf("\nread_ack : %d\n",read_ack1);
		// 		printf("readbuffer : %x      ",readbuffer[0]);
		delay_ms(25);
		static uint8_t buffer[6];
		int32_t read_ack = i2c_m_sync_cmd_read(&I2C_0, 0x3b, buffer, 6);
		//printf("\nread_ack : %d\n",read_ack);
		// 		for(int j =0;j<=6;j++)
		// 		printf("i : %x    buffer : %x      ",j,buffer[j]);
		int16_t acX = buffer[counter++] << 8 | buffer[counter++]; // 0x3B (ACCEL_XOUT_H) & 0x3C (ACCEL_XOUT_L)
		//printf("X: %d, Counter: %d\n",acX,counter);
		int16_t acY = buffer[counter++] << 8 | buffer[counter++]; // 0x3D (ACCEL_YOUT_H) & 0x3E (ACCEL_YOUT_L)
		//printf("Y: %d, Counter: %d\n",acY,counter);
		int16_t acZ = buffer[counter++] << 8 | buffer[counter++]; // 0x3F (ACCEL_ZOUT_H) & 0x40 (ACCEL_ZOUT_L)
		printf("X: %d        Y: %d        Z: %d\n",acX,acY,acZ);
		counter=0;
		i++;

		
	}
	*/
	
}

