#include "atmel_start.h"
#include "driver_init.h"
#include "utils.h"
#include <stdio.h>

#define ADDRESS    0x68


static uint8_t buffer[14];

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	int32_t ack3 = i2c_m_sync_enable(&I2C_0);
	printf("I2C Enabled - %d\n",ack3);
	
	int32_t slave_addr = i2c_m_sync_set_slaveaddr(&I2C_0, ADDRESS, I2C_M_SEVEN);
	
	printf("Masked Slave Address - %d\n", slave_addr);
	int counter = 0;
	uint8_t pwr_mgmt =  0;

 	int32_t power_up = i2c_m_sync_cmd_write(&I2C_0, 0x6b, &pwr_mgmt, 1);

	printf("Power up ack : %d\n", power_up);
	
	
	
}
