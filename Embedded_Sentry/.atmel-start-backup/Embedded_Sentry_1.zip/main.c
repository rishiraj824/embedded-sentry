#include "atmel_start.h"
#include "driver_init.h"
#include "utils.h"
#include <inttypes.h>
#include <stdio.h>

#define ADDRESS     0x68
#define WHO_AM_I    0x75


struct io_descriptor *I2C_0_io;
static uint8_t buffer[14];

void UART_EDBG_init(){
	uart_s
}


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	i2c_m_sync_init(&I2C_0, SERCOM0);
	
	i2c_m_sync_get_io_descriptor(&I2C_0, &I2C_0_io);
	i2c_m_sync_enable(&I2C_0);
	i2c_m_sync_set_slaveaddr(&I2C_0, ADDRESS, I2C_M_SEVEN);
	

	
	/* Replace with your application code */
	while (1) {
		//gpio_toggle_pin_level(BLINK_LED);
		// delay
		//delay_ms(600);
		uint32_t data = i2c_m_sync_cmd_read(&I2C_0, ADDRESS, buffer, 14);
		
		int counter = 0;

		int16_t acX = buffer[counter++] << 8 | buffer[counter++]; // 0x3B (ACCEL_XOUT_H) & 0x3C (ACCEL_XOUT_L)
		int16_t acY = buffer[counter++] << 8 | buffer[counter++]; // 0x3D (ACCEL_YOUT_H) & 0x3E (ACCEL_YOUT_L)
		int16_t acZ = buffer[counter++] << 8 | buffer[counter++]; // 0x3F (ACCEL_ZOUT_H) & 0x40 (ACCEL_ZOUT_L)
		int16_t tmp = buffer[counter++] << 8 | buffer[counter++]; // 0x41 (TEMP_OUT_H) & 0x42 (TEMP_OUT_L)
		//int16_t gyX = buffer[counter++] << 8 | buffer[counter++]; // 0x43 (GYRO_XOUT_H) & 0x44 (GYRO_XOUT_L)
		//int16_t gyY = buffer[counter++] << 8 | buffer[counter++]; // 0x45 (GYRO_YOUT_H) & 0x46 (GYRO_YOUT_L)
		//int16_t gyZ = buffer[counter++] << 8 | buffer[counter++]; // 0x47 (GYRO_ZOUT_H) & 0x48 (GYRO_ZOUT_L)

		//printf("X: %d, Y: %d, Z: %d, Temp: %d", acX, acY, acZ, tmp);
		//snprintf("%" PRIu32 "\n", data);
	}
}
